# Stress Test Report

##### PC = Intel(R)Core(TM)i5 Cores=4 RAM=8G

## 1° Stress Test:
        - Number of users: 50
        - Rate: 20

Here I'm testing 50 users, max wait time in this case is 47.000 m secs. Model is not working that well because of the amount of users tested, it took lot of time to standarize the test so as to get the conclusion

![Test 50 users](/sprint-4-project/stress_test/50-20.png)

## 2° Stress Test:
        - Number of users: 200
        - Rate: 10

Here I'm testing 200, same as previous stress test but with even more users. The time users wait is even more and they have their request cancelled.

![Test 200 users](/sprint-4-project/stress_test/200-10.png)

## Scaled Model:
        - Number of users: 50
        - Rate: 20

Here I'm testing the scaled model with 50 

![Scaled 50 users](/sprint-4-project/stress_test/Scaling50-20.png)

## Scaled Model 2:
        - Number of users: 8
        - Rate: 2

Here I'm testing the scaled model only 8 users were I can see that the model runs perfeclty without leaving users with no response and, accomplishing time response at 0 m secs

![Scaled 8 users](/sprint-4-project/stress_test/Scaling8-1.png)